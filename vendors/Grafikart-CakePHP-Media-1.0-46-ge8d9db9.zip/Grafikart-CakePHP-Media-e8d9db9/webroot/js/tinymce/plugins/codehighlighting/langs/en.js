// UK lang variables
tinyMCE.addI18n('en.codehighlighting',{
codehighlighting_desc : "Code Highlighting",
codehighlighting_title : "Code Highlighting",
codehighlighting_languagepicker : "Choisissez votre langage",
codehighlighting_pagecode : "Insérer votre code ici",
codehighlighting_button_desc: "Insérer du code",
codehighlighting_nogutter : "No Gutter",
codehighlighting_collapse : "Collapes",
codehighlighting_nocontrols : "No Controls",
codehighlighting_showcolumns : "Show Columns"
});
